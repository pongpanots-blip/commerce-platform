# Superseded canonical admin navigation proposal

**Current status:** the first-slice application changes described below were archived and
undone after the user's explicit Stitch exclusion. This mapping remains a reviewable proposal,
not current behavior. Existing navigation, deep links, pages and shared defaults are unchanged.
See [the current protection audit](../reviews/admin-task-navigation/route-protection.md)
and [current implementation report](../reviews/admin-task-navigation/README.md).

Implementation branch: `redesign/admin-task-navigation`, based on clean `work` at
`69b13b2d188d4f7fb1d9bfbe5136fa693fc0bbf9`. The requested recent master snapshot
`e4346b7687c196ba4a1a8ca276e74448b90c3317` is different; the checkout was not reset.
No AGENTS.md or local SKILL.md was found in the checkout or the available `.agents` / `.codex` directories.
The existing shared UI and `workspace-redesign.md` are implementation references.

## Feature mapping

| Feature | Canonical menu entry | Other URLs and capabilities |
| --- | --- | --- |
| Customer service | `/cs` | Task directory linking to `/cs/orders/new`, `/cs/samples`, `/cs/accounts/merge` (admin only) |
| Sample requests | Customer service → `/cs/samples` | `/j/cs/sample-requests` redirects with query/hash preserved; review actions have `/cs/samples/:id/:decision` URLs |
| Coupons | `/j/coupons` | `/josh/coupons` remains a feature action for masked records and activation; not a global menu item |
| Suppliers | `/j/suppliers` | `/josh/suppliers` retains its create/edit actions as feature actions |
| Credit applications | `/j/credit-terms` | `/josh/credit_terms` retains review/approval actions as a feature action |
| Admin access | `/j/admin-access` | `/josh/admin_access` retains approval/role assignment as a feature action |
| Shipments | `/j/shipments` | `/josh/shipments` retains the data-copy view within the feature |
| Payments | `/j/payment-transactions` | `/josh/payments` retains the data-copy view within the feature |
| Credit notes / credit backs | `/j/credit-notes`, `/j/credit-backs` | `/josh/credit_notes`, `/josh/credit_backs` remain accessible within their features |
| Invoices | `/j/invoices` | `/josh/invoices` remains accessible within the feature; `/j/billing` retains its different company/billing scope |
| Campaigns / segments / identity checks | `/j/promotions/campaigns`, `/j/segments`, `/j/kyc` | Corresponding `/josh/campaigns`, `/josh/segments`, `/josh/kyc` data-copy views remain accessible within their features |
| Internal documents | `/josh/internal_docs` | Independent live create/delete capability stays discoverable in Settings |
| Add product / import orders | Product and order feature actions | `/j/product/create`, `/j/order/import` remain routable, permission filtered and highlighted under their feature |
| Product records / shop catalog / product reports | `/products`, `/j/allproducts`, `/reports/products` | Kept separate: operational records, storefront content and reporting have different responsibilities and role policies |
| Operational orders / storefront orders / order reports | `/orders`, `/j/order`, `/reports/orders` | Kept separate for the same scope and permission reasons |
| Contact records / companies / customer reports | `/customers`, `/j/company`, `/reports/customers` | Kept separate for the same scope and permission reasons |

No data-copy route is redirected into a live-only page: offline availability and live actions remain intact.
Aliases highlight the feature's single canonical sidebar entry. Legacy route authorization is evaluated on
the requested URL, before any redirect, so canonicalizing navigation does not grant new permissions.
The archived slice reduced the menu to 104 destinations including Home and Dashboard from 119. This was a
15-entry consolidation of verified overlap and feature actions, not a claim that all remaining menus
have been redesigned. That task-directory implementation is archived; the current customer-service entry retains its original local-state tabs.

## Implementation phases

1. Replace destination-count/equality policy tests with feature/alias/permission invariants. Remove verified
   duplicate and global create/import menu entries. Add permission-filtered feature actions and a mapping
   that accounts for every old destination without requiring it to remain a menu entry.
2. Implement route-based customer-service tasks and sample reviews with URL filters, loading skeletons,
   retry and empty states, persisted success feedback, authoritative status badges, duplicate-submit guards
   and interrupted-form protection. Keep existing API payloads and state-transition capabilities.
3. Add reusable stale-response-safe reads, mutation guards and skeletons. Apply them to the product-master
   approval queue, including actual backend approved/rejected counts and failed-refresh handling.
4. Run focused unit/component and browser checks sequentially, with one worker. Mocked browser APIs are
   interaction evidence only; they do not prove external service persistence. Record new screenshots and
   exact verification limits.

## Remaining breadth

Stock receive/count/adjust/transfer, resource creation, staff creation and integration creation still need
separate action URLs. Other legacy editors and lists still need the shared request/mutation/state patterns
applied and their unique business workflows checked. This slice does not redesign the whole application.

Sample review notes recover across Back/Forward and reload within the same staff session, and completed
requests cannot replay an obsolete decision after a fresh read. Other drafts, including on-behalf order
lines and merge inputs, do not yet recover on browser Back. The existing shared unsaved-form guard
protects links and reload/tab close, but does not intercept browser Back. An interrupted network write
still requires reconciling authoritative server state; backend idempotency has not been added here.

## Verified outcome

See [the validation report and screenshots](../reviews/admin-task-navigation/README.md). No push, PR,
merge, deployment, production data changes, database credentials or external app credentials were used.
