#!/usr/bin/env node
// All APIs are intercepted fixtures. No credentials, remote writes or database access.
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright';

const base = process.env.ADMIN_URL ?? 'http://127.0.0.1:4403';
assert.ok(['localhost', '127.0.0.1'].includes(new URL(base).hostname), 'Local preview required');
const output = 'docs/reviews/admin-task-navigation';
mkdirSync(output, { recursive: true });
const sampleId = '00000000-0000-4000-8000-000000000001';
const browser = await chromium.launch({ headless: true, ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH } : {}) });
const checks = [], errors = [], screenshots = [];
const roles = ['admin', 'marketing', 'merchandising', 'cs', 'sales_manager', 'business_analyst', 'graphic', 'sale'];
const aliases = ['/josh/kyc', '/josh/credit_terms', '/josh/admin_access', '/josh/shipments', '/josh/payments', '/josh/credit_notes', '/josh/credit_backs', '/josh/invoices', '/josh/coupons', '/josh/campaigns', '/josh/segments', '/josh/suppliers', '/j/cs/sample-requests', '/j/product/create', '/j/order/import'];
const gate = () => { let release; const promise = new Promise(resolve => { release = resolve; }); return { promise, release }; };
async function open(role, locale = 'en', path = '/home', options = {}) {
  const context = await browser.newContext({ reducedMotion: 'reduce', ...options });
  const state = { samples: [{ id: sampleId, sku: 'FLOUR-01', quantity: 2, status: 'pending', company_name: 'Harbor Kitchen', created_at: '2026-10-09T03:00:00Z' }], requests: [], writes: [], pending: true };
  const claims = Buffer.from(JSON.stringify({ sub: 'task-ui-fixture', email: 'task-ui@example.invalid', role, exp: 4102444800 })).toString('base64url');
  await context.addInitScript(({ claims, locale }) => {
    if (!sessionStorage.getItem('task-fixture-started')) {
      sessionStorage.setItem('cp_admin_token', `e30.${claims}.fixture`);
      sessionStorage.setItem('task-fixture-started', 'yes');
      localStorage.setItem('cp_ui_locale', locale);
    }
  }, { claims, locale });
  await context.route('**/api/**', async route => {
    const request = route.request();
    const url = new URL(request.url()); const path = url.pathname.replace(/^\/api/, '');
    const body = request.postDataJSON();
    state.requests.push({ method: request.method(), path, body });
    const answer = (json, status = 200) => route.fulfill({ status, json });
    if (path === '/admin/auth/me') {
      if (state.meGate) await state.meGate.promise;
      if (state.meFail) { state.meFail = false; return answer({ message: 'Identity check unavailable' }, 503); }
      return answer({ userId: 'task-ui-fixture', email: 'task-ui@example.invalid', role, mustChangePassword: false });
    }
    if (path === '/admin/stats') return answer({ webhooksFailed: 0 });
    if (path === '/reports/health') return answer({ now: { problems: [] } });
    if (path === '/ownership') return answer({ productMaster: true });
    if (path === '/product-masters/pending') return answer({ items: state.pending ? [{ sku: 'FLOUR-01', patch: { pack_size: 2 }, current: { pack_size: 1 }, received_at: '2026-10-09T03:00:00Z' }] : [], total: state.pending ? 1 : 0, page: 1, limit: 20 });
    if (path === '/product-masters/pending/approve') {
      state.writes.push({ path, body }); state.pending = false;
      return answer({ approved: 1 });
    }
    if (path === '/reports/customers') return answer({ items: [{ id: 'company-1', name: 'Harbor Kitchen' }], total: 1 });
    if (path === '/reports/customers/company-1') return answer({ id: 'company-1', name: 'Harbor Kitchen', credit_limit: 10000, credit_used: 0, credit_term_days: 30, users: [{ id: 'user-1', first_name: 'Fixture', role: 'buyer', is_active: true }], branches: [{ id: 'branch-1', name: 'Main kitchen' }] });
    if (path === '/reports/products') return answer({ items: [{ product_inventory_id: 'product-1', product_inventory_sku: 'FLOUR-01', name_th: 'Flour fixture', selling_unit_price: 50, selling_unit: 'bag' }], total: 1 });
    if (path === '/josh/admin-call') {
      if (body.method === 'GET' && body.path === '/cs-admin/sample-requests') {
        if (state.readGate) await state.readGate.promise;
        if (state.expire) return answer({ message: 'Expired' }, 401);
        if (state.readFail) { state.readFail = false; return answer({ message: '403 fixture read denied' }, 403); }
        const filtered = state.samples.filter(row => !body.query?.status || row.status === body.query.status);
        return answer({ data: { items: filtered } });
      }
      if (body.method === 'PATCH' && body.path === `/cs-admin/sample-requests/${sampleId}`) {
        state.writes.push({ path: body.path, body: body.body });
        if (state.patchGate) await state.patchGate.promise;
        if (state.patchFail) { state.patchFail = false; return answer({ message: 'Fixture write failed' }, 503); }
        Object.assign(state.samples[0], body.body);
        return answer({ data: state.samples[0] });
      }
      if (body.method === 'POST' && body.path === '/cs-admin/orders/quote') return answer({ data: { total: 100, currency: 'THB' } });
      if (body.method === 'POST' && body.path === '/cs-admin/orders/place-on-behalf') {
        state.writes.push({ path: body.path, body: body.body });
        if (state.orderGate) await state.orderGate.promise;
        return answer({ data: { order_id: 'fixture-order-1' } });
      }
    }
    if (path.startsWith('/reports/backoffice/')) return answer({ key: path.split('/').pop(), title: 'Saved coupon records', joshPage: '/coupons', columns: [], byStatus: [], items: [], total: 0, page: 1, limit: 20 });
    // Unhandled APIs fail visibly; a mock cannot accidentally reach an actual service.
    return answer({ message: 'Fixture endpoint unavailable' }, 503);
  });
  const page = await context.newPage(); page.setDefaultTimeout(10000);
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(base + path); await page.locator('main h1').waitFor();
  return { context, page, state };
}
async function screenshot(page, name) {
  await page.screenshot({ path: `${output}/${name}.png`, fullPage: true }); screenshots.push(`${name}.png`);
}
async function expand(page) {
  const collapsed = page.locator('aside nav button[aria-controls][aria-expanded="false"]');
  while (await collapsed.count()) await collapsed.first().click();
}
async function checkOverflow(page) {
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'No document overflow');
}
try {
  for (const role of roles) for (const locale of ['th', 'en']) {
    const { context, page } = await open(role, locale);
    await expand(page);
    for (const alias of aliases) assert.equal(await page.locator(`aside a[href="${alias}"]`).count(), 0, `${role} canonicalizes ${alias}`);
    if (role === 'cs' || role === 'admin') {
      await page.locator('aside a[href="/cs"]').focus(); await page.keyboard.press('Enter');
      await page.locator('main a[href="/cs/samples"]').waitFor();
      assert.equal(await page.locator('main a[href="/cs/accounts/merge"]').count(), role === 'admin' ? 1 : 0);
    }
    assert.equal(await page.locator('aside a[href="/josh/internal_docs"]').count(), role === 'admin' ? 1 : 0);
    await checkOverflow(page); checks.push(`${role} ${locale}: canonical menu, role tasks, keyboard and layout`);
    await context.close();
  }
  {
    const { context, page, state } = await open('cs');
    state.meGate = gate(); state.meFail = true;
    await page.goto(base + '/cs');
    await page.locator('[aria-busy="true"]').waitFor();
    assert.equal(await page.locator('main').count(), 0, 'Wait for authoritative password check');
    state.meGate.release(); state.meGate = null;
    await page.getByRole('alert').waitFor();
    await page.getByRole('button', { name: 'Try again', exact: true }).click();
    await page.locator('main h1').waitFor();
    checks.push('Identity/password check: accessible startup skeleton, failed read blocks content, retry restores task home');
    await context.close();
  }
  {
    const { context, page, state } = await open('cs', 'en', '/j/cs/sample-requests?status=pending&source=saved#requests');
    assert.equal(new URL(page.url()).pathname, '/cs/samples'); assert.ok(page.url().includes('source=saved#requests'));
    await page.getByText('Harbor Kitchen', { exact: true }).filter({ visible: true }).waitFor();
    await screenshot(page, 'samples-en');
    await page.getByRole('tab', { name: 'Approved', exact: true }).click();
    assert.ok(page.url().includes('status=approved')); await page.getByText('No requests match this filter', { exact: true }).waitFor();
    await page.goBack(); await page.getByText('Harbor Kitchen', { exact: true }).filter({ visible: true }).waitFor();
    await page.goForward(); await page.getByText('No requests match this filter', { exact: true }).waitFor();
    await page.goBack();
    await page.locator(`main a[href*="${sampleId}/approved"]`).filter({ visible: true }).click();
    await page.locator('textarea').fill('Keep this review note');
    await page.goBack(); await page.goForward();
    assert.equal(await page.locator('textarea').inputValue(), 'Keep this review note', 'Interrupted review restores draft');
    await page.getByRole('checkbox').check();
    state.patchFail = true;
    await page.getByRole('button', { name: 'Confirm and save', exact: true }).click();
    await page.getByRole('alert').waitFor();
    assert.equal(await page.getByText('Request status saved', { exact: false }).count(), 0);
    assert.equal(await page.locator('textarea').inputValue(), 'Keep this review note');
    state.patchGate = gate();
    await page.getByRole('button', { name: 'Confirm and save', exact: true }).click();
    await page.waitForFunction(() => document.querySelector('form button[type="submit"]')?.disabled);
    await page.locator('form').evaluate(form => { form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); });
    assert.equal(state.writes.length, 2, 'One failed request plus one retry, no duplicate write');
    assert.equal(state.samples[0].status, 'pending');
    state.patchGate.release();
    await page.getByText('Request status saved', { exact: false }).waitFor();
    assert.equal(state.samples[0].status, 'approved');
    await screenshot(page, 'sample-success-en');
    await page.reload(); await page.getByText('This request has changed status', { exact: false }).waitFor();
    assert.equal(await page.locator('textarea').count(), 0);
    checks.push('Samples: alias/query/reload/back/forward, interrupted note, failed save, retry, duplicate-submit guard and authoritative status');
    await context.close();
  }
  {
    const { context, page, state } = await open('cs', 'en', '/cs');
    state.readGate = gate(); state.readFail = true;
    await page.locator('main a[href="/cs/samples"]').click();
    await page.locator('[aria-busy="true"]').waitFor();
    assert.equal(await page.getByText('No requests', { exact: true }).count(), 0);
    assert.equal(await page.locator('[aria-busy="true"] [aria-hidden="true"]').evaluate(node => getComputedStyle(node).animationName), 'none', 'Reduced motion disables skeleton animation');
    state.readGate.release(); state.readGate = null;
    await page.getByRole('alert').waitFor(); await page.getByRole('button', { name: 'Try again', exact: true }).click();
    await page.getByText('Harbor Kitchen', { exact: true }).filter({ visible: true }).waitFor();
    state.expire = true; await page.getByRole('button', { name: 'Refresh', exact: true }).click();
    await page.locator('input[type="email"]').waitFor();
    assert.ok(page.url().includes('/login?redirect='));
    checks.push('Samples: loading skeleton, reduced motion, 403/retry and expired session login');
    await context.close();
  }
  {
    const { context, page } = await open('cs', 'th', '/cs/samples', { viewport: { width: 390, height: 844 } });
    await page.getByText('Harbor Kitchen', { exact: true }).filter({ visible: true }).waitFor();
    await checkOverflow(page); await screenshot(page, 'samples-phone-th');
    const menu = page.locator('aside button[aria-controls]').first(); await menu.click();
    assert.equal(await menu.getAttribute('aria-expanded'), 'true');
    await page.locator('aside a[href="/home"]').click(); await page.locator('main h1').waitFor();
    assert.equal(await menu.getAttribute('aria-expanded'), 'false');
    checks.push('Thai phone: scroll containment, mobile menu opens and closes after navigation');
    await context.close();
  }
  {
    const { context, page, state } = await open('cs', 'en', '/cs/orders/new');
    await page.locator('main').getByRole('searchbox').first().fill('Harbor'); await page.getByRole('button', { name: 'Search', exact: true }).click();
    await page.locator('main select').first().selectOption('company-1');
    await page.locator('main select').nth(1).selectOption('user-1'); await page.locator('main select').nth(2).selectOption('branch-1');
    await page.locator('main').getByRole('searchbox').nth(1).fill('Flour'); await page.getByRole('button', { name: 'Search products', exact: true }).click();
    await page.getByRole('button', { name: 'Add', exact: true }).click();
    await page.getByRole('button', { name: 'Calculate Price (josh)', exact: true }).click();
    await page.getByRole('button', { name: 'Place Order', exact: true }).waitFor();
    state.orderGate = gate(); page.on('dialog', dialog => dialog.accept());
    await page.getByRole('button', { name: 'Place Order', exact: true }).click();
    await page.waitForFunction(() => document.querySelector('fieldset')?.disabled);
    await page.locator('form').last().evaluate(form => { form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); });
    assert.equal(state.writes.length, 1); assert.equal(state.writes[0].body.user_id, 'user-1');
    assert.deepEqual(state.writes[0].body.items, [{ product_inventory_id: 'product-1', quantity: 1 }]);
    assert.equal(await page.getByText('Order created', { exact: false }).count(), 0);
    state.orderGate.release(); await page.getByText('Order created', { exact: false }).waitFor();
    checks.push('On-behalf order: customer/branch selection, quote, unchanged payload, locked checkout and success after response');
    await context.close();
  }
  {
    const { context, page, state } = await open('merchandising', 'en', '/product-master-queue');
    await page.getByRole('checkbox', { name: 'Select FLOUR-01', exact: true }).check();
    await page.getByRole('button', { name: /Approve/ }).click();
    await page.getByText('Approved 1 records', { exact: true }).waitFor();
    assert.equal(state.writes.length, 1); assert.deepEqual(state.writes[0].body, { skus: ['FLOUR-01'] });
    await page.getByText('No pending approvals', { exact: true }).waitFor();
    await screenshot(page, 'queue-success-en');
    checks.push('Product master queue: persisted-result count, selected payload and empty after refresh');
    await context.close();
  }
  {
    const { context, page } = await open('cs', 'en', '/cs/accounts/merge');
    await page.getByText('You do not have permission for this task', { exact: true }).waitFor();
    assert.equal(await page.locator('form').count(), 0); await context.close();
    const admin = await open('admin', 'en', '/josh/coupons');
    await admin.page.locator('aside a[href="/j/coupons"][aria-current="page"]').waitFor();
    await admin.page.locator('main a[href="/j/coupons"]').waitFor();
    checks.push('Direct admin-only task denied to CS; saved-record alias highlights canonical coupons');
    await admin.context.close();
  }
  assert.deepEqual(errors, []);
  writeFileSync(`${output}/results.json`, JSON.stringify({ apiMode: 'intercepted fixtures; no external persistence tested', browser: await browser.version(), checks, screenshots, errors }, null, 2));
  console.log(`PASS: ${checks.length} browser scenarios, ${screenshots.length} screenshots; all APIs mocked`);
} finally { await browser.close(); }
