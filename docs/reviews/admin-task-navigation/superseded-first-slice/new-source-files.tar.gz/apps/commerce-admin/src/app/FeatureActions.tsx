import { Link, useLocation } from 'react-router-dom';
import { currentNavItem, uiText, useUiLocale } from '@cp/ui';
import { isRouteAllowed } from '../lib/landing';
import { FEATURE_ACTIONS, FEATURE_HOMES } from './features';
import { navFor } from './navigation';

/** Unique legacy capabilities are reachable from their feature, with their original permissions. */
export function FeatureActions({ role }: { role?: string }) {
  useUiLocale();
  const { pathname } = useLocation();
  const home = currentNavItem(navFor(role), pathname)?.link.to;
  const actions = FEATURE_HOMES[pathname]
    ? [{ to: FEATURE_HOMES[pathname], label: 'กลับหน้ารายการ' }]
    // Product creation and order import already have primary actions in their list headers.
    : home === pathname && !['/j/allproducts', '/j/order'].includes(home) ? FEATURE_ACTIONS[home] ?? [] : [];
  const permitted = actions.filter(action => isRouteAllowed(role, action.to));
  if (!permitted.length) return null;
  return <nav aria-label={uiText('การทำงานอื่น')} className="mx-auto mb-4 flex max-w-[1240px] flex-wrap gap-2">
    {permitted.map(action => <Link key={action.to} to={action.to} className="inline-flex min-h-10 items-center rounded-lg border border-secondary-container bg-white px-3 text-sm font-medium text-primary focus-visible:outline-2 focus-visible:outline-primary">{uiText(action.label)}</Link>)}
  </nav>;
}
