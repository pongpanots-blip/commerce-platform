// @vitest-environment jsdom
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { MemoryRouter, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { setUiLocale, confirmLeaveIfDirty } from '@cp/ui';
import { joshAdmin } from '../../lib/api';
import { CsDesk, SampleRequestsRedirect, sampleDecisions } from './CsDesk';

vi.mock('../../lib/api', () => ({ session: { claims: () => ({ sub: 'fixture' }) }, joshAdmin: { get: vi.fn(), call: vi.fn() }, joshCustomerApi: { list: vi.fn(), detail: vi.fn() }, joshProductApi: { list: vi.fn() } }));
(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
HTMLDialogElement.prototype.showModal ??= function () { this.open = true; };
HTMLDialogElement.prototype.close ??= function () { this.open = false; };
let root: Root;
let container: HTMLDivElement;
let rows: Record<string, unknown>[];
function Location() {
  const location = useLocation(); const navigate = useNavigate();
  return <><output>{location.pathname + location.search + location.hash}</output><button onClick={() => navigate(-1)}>Back test</button><button onClick={() => navigate(1)}>Forward test</button></>;
}
const text = () => container.textContent ?? '';
const button = (label: string) => [...container.querySelectorAll('button')].find(node => node.textContent === label)!;
async function render(path: string, role = 'cs') {
  await act(async () => root.render(<MemoryRouter initialEntries={[path]}><Location /><Routes>
    <Route path="/j/cs/sample-requests" element={<SampleRequestsRedirect role={role} />} />
    <Route path="/cs/samples/:id/:decision" element={<CsDesk role={role} />} />
    <Route path="/cs/*" element={<CsDesk role={role} />} />
  </Routes></MemoryRouter>));
}
const deferred = <T,>() => { let resolve!: (value: T) => void; let reject!: (reason: unknown) => void; const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; };
beforeEach(() => {
  vi.clearAllMocks(); sessionStorage.clear(); setUiLocale('en');
  rows = [{ id: 'request-1', sku: 'SKU-1', quantity: 2, status: 'pending', company_name: 'Customer one' }];
  vi.mocked(joshAdmin.get).mockImplementation(async () => ({ data: { items: rows.map(row => ({ ...row })) } }));
  container = document.createElement('div'); document.body.append(container); root = createRoot(container);
});
afterEach(() => { act(() => root.unmount()); container.remove(); setUiLocale('th'); vi.restoreAllMocks(); });

it('preserves legacy pending fulfillment and does not offer completed decisions again', () => {
  expect(sampleDecisions('pending')).toEqual(['approved', 'rejected', 'fulfilled']);
  expect(sampleDecisions('approved')).toEqual(['fulfilled']);
  for (const state of ['rejected', 'fulfilled', 'unknown']) expect(sampleDecisions(state)).toEqual([]);
});

it('redirects the old samples deep link preserving filters and hash', async () => {
  await render('/j/cs/sample-requests?status=pending&source=saved#requests');
  expect(container.querySelector('output')!.textContent).toBe('/cs/samples?status=pending&source=saved#requests');
  expect(joshAdmin.get).toHaveBeenCalledWith('/cs-admin/sample-requests', { status: 'pending' });
  expect(text()).toContain('Customer one');
});

it('uses task URLs and browser history for customer-service navigation', async () => {
  await render('/cs');
  expect(joshAdmin.get).not.toHaveBeenCalled();
  expect(container.querySelector('a[href="/cs/accounts/merge"]')).toBeNull();
  await act(async () => (container.querySelector('a[href="/cs/samples"]') as HTMLAnchorElement).click());
  expect(container.querySelector('output')!.textContent).toBe('/cs/samples');
  await act(async () => button('Back test').click());
  expect(container.querySelector('output')!.textContent).toBe('/cs');
  await act(async () => button('Forward test').click());
  expect(text()).toContain('Customer one');
});

it('blocks direct merge access and makes no service calls for a denied role', async () => {
  await render('/cs/accounts/merge');
  expect(text()).toContain('You do not have permission');
  expect(joshAdmin.get).not.toHaveBeenCalled(); expect(joshAdmin.call).not.toHaveBeenCalled();
});

it('shows loading, failure and retry rather than a false empty result', async () => {
  const loading = deferred<unknown>(); vi.mocked(joshAdmin.get).mockReturnValueOnce(loading.promise);
  await render('/cs/samples');
  expect(container.querySelector('[aria-busy="true"]')).not.toBeNull();
  expect(text()).not.toContain('No requests');
  await act(async () => loading.reject(new Error('403 forbidden')));
  expect(container.querySelector('[role="alert"]')).not.toBeNull();
  expect(text()).not.toContain('No requests');
  await act(async () => button('Try again').click());
  expect(text()).toContain('Customer one');
});

it('reports malformed service responses as errors, and provides a useful empty state', async () => {
  vi.mocked(joshAdmin.get).mockResolvedValueOnce({ unexpected: 'shape' });
  await render('/cs/samples?status=fulfilled');
  expect(container.querySelector('[role="alert"]')).not.toBeNull();
  rows = [];
  await act(async () => button('Try again').click());
  expect(text()).toContain('No requests');
  expect(button('Clear Filters')).toBeTruthy();
});

it('waits for persistence, locks duplicate submit, reloads authoritative status, and prevents replay', async () => {
  const patch = deferred<unknown>(); vi.mocked(joshAdmin.call).mockReturnValueOnce(patch.promise);
  await render('/cs/samples/request-1/approved?status=pending');
  await act(async () => (container.querySelector('input[type="checkbox"]') as HTMLInputElement).click());
  const form = container.querySelector('form')!;
  await act(async () => { form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); });
  expect(joshAdmin.call).toHaveBeenCalledTimes(1);
  expect(joshAdmin.call).toHaveBeenCalledWith('PATCH', '/cs-admin/sample-requests/request-1', { status: 'approved' });
  expect(text()).not.toContain('Request status saved');
  rows[0].status = 'approved';
  await act(async () => patch.resolve({ data: rows[0] }));
  expect(text()).toContain('Request status saved');
  expect(container.querySelector('form')).toBeNull();
  expect(text()).toContain('Approve');
  await act(async () => root.render(null));
  await render('/cs/samples/request-1/approved');
  expect(text()).toContain('This request has changed status');
  expect(container.querySelector('form')).toBeNull();
});

it('keeps failed reviews editable and protects unsaved notes until persistence succeeds', async () => {
  vi.mocked(joshAdmin.call).mockRejectedValueOnce(new Error('Not saved'));
  await render('/cs/samples/request-1/rejected');
  const input = container.querySelector('textarea')!;
  await act(async () => {
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(input, 'Please retry');
    input.dispatchEvent(new Event('input', { bubbles: true }));
    (container.querySelector('input[type="checkbox"]') as HTMLInputElement).click();
  });
  await act(async () => container.querySelector('form')!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })));
  expect(text()).not.toContain('Request status saved');
  expect(container.querySelector('textarea')!.value).toBe('Please retry');
  let leave!: Promise<boolean>;
  await act(async () => { leave = confirmLeaveIfDirty(); });
  expect(container.querySelector('dialog[open]')).not.toBeNull();
  await act(async () => (container.querySelector('dialog button') as HTMLButtonElement).click());
  await expect(leave).resolves.toBe(false);
  vi.mocked(joshAdmin.call).mockImplementationOnce(async () => { rows[0].status = 'rejected'; return { data: rows[0] }; });
  await act(async () => container.querySelector('form')!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })));
  expect(text()).toContain('Request status saved');
  await expect(confirmLeaveIfDirty()).resolves.toBe(true);
});

it('restores a note after interrupted navigation without claiming it was saved', async () => {
  sessionStorage.setItem('cp-sample-note:fixture:request-1:approved', 'Draft note');
  await render('/cs/samples/request-1/approved');
  expect(container.querySelector('textarea')!.value).toBe('Draft note');
  expect(text()).not.toContain('Request status saved');
});

it('treats an explicit business failure in HTTP success as a failed save', async () => {
  vi.mocked(joshAdmin.call).mockResolvedValueOnce({ status: false, message: 'Request already changed' });
  await render('/cs/samples/request-1/approved');
  await act(async () => (container.querySelector('input[type="checkbox"]') as HTMLInputElement).click());
  await act(async () => container.querySelector('form')!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })));
  expect(text()).not.toContain('Request status saved');
  expect(container.querySelector('[role="alert"]')).not.toBeNull();
  expect(container.querySelector('form')).not.toBeNull();
});

it('does not enable an invalid action or a missing record', async () => {
  await render('/cs/samples/request-1/invalid');
  expect(container.querySelector('form')).toBeNull();
  await act(async () => root.render(null));
  await render('/cs/samples/missing/approved');
  expect(text()).toContain('Request not found');
  expect(joshAdmin.call).not.toHaveBeenCalled();
});

it('validates distinct merge IDs, preserves the confirmation boundary and reports success after persistence', async () => {
  const primary = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
  const duplicate = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
  const set = async (first: string, second: string) => {
    await act(async () => [...container.querySelectorAll('form input')].forEach((input, index) => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(input, index ? second : first);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }));
  };
  const submit = async () => { await act(async () => container.querySelector('form')!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }))); };
  await render('/cs/accounts/merge', 'admin');
  await set(primary, primary.toUpperCase()); await submit();
  expect(joshAdmin.call).not.toHaveBeenCalled();
  await set(primary, duplicate);
  const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false); await submit();
  expect(joshAdmin.call).not.toHaveBeenCalled();
  confirm.mockReturnValue(true);
  const request = deferred<unknown>(); vi.mocked(joshAdmin.call).mockReturnValueOnce(request.promise);
  await submit();
  expect(joshAdmin.call).toHaveBeenCalledWith('POST', '/cs-admin/accounts/merge', { primary_user_id: primary, duplicate_user_id: duplicate });
  expect((container.querySelector('form input') as HTMLInputElement).disabled).toBe(true);
  expect(text()).not.toContain('Merged');
  await act(async () => request.resolve({ merged: true }));
  expect(container.querySelector('form input')!.getAttribute('value')).toBe('');
  expect(container.querySelector('[role="status"]')).not.toBeNull();
});
